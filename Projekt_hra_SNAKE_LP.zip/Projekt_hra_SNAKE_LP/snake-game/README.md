# Clean Code pro hru SNake (Hada)

Tato implementace hry Snake demonstruje použití principů čistého kódu. GUI je odděleno od logiky hry a kód je snadno rozšiřitelný.

## Struktura projektu

- `src/Game.cs` - Řídí celkový průběh hry
- `src/Snake.cs` - Reprezentuje hada
- `src/Berry.cs` - Reprezentuje ovoce
- `src/Position.cs` - Zastupuje pozici na obrazovce
- `src/Renderer.cs` - Stará se o vykreslení hry na konzoli
- `src/InputHandler.cs` - Zpracovává vstupy uživatele

## Spuštění

Spusťte program přes `Program.cs`.


## .Gitiignore

# Složky s automaticky generovanými soubory
bin/
obj/

# Nastavení uživatelského prostředí (není třeba sdílet mezi vývojáři)
*.user
*.suo
*.vs/
